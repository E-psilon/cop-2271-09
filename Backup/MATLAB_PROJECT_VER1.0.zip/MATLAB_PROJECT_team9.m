%Still working on GUI for the program should be done by BETA 2.0
function MATLAB_PROJECT_team9()
      fprintf('%s\n'     ,  '----------------------------------------')
      fprintf('%s\n'     ,  '-------------    Team9    --------------')
      fprintf('%s\n'     ,  '---------    Section: 12792   ----------')
      fprintf('%s\n'     ,  '---------    Darren Keane     ----------')
      fprintf('%s\n'     ,  '---------    Griffin Woods    ----------')
      fprintf('%s\n'     ,  '----------    Megan Hobbs    -----------')
      fprintf('%s\n'     ,  '----------    Yanelly S.     -----------')
      fprintf('%s\n'     ,  '----------------------------------------')
      
      c = input("1. Citations");
      if c == 1
          Citation_team9()
      end
end


