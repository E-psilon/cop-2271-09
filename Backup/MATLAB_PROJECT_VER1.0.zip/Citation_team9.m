function Citation_team9()
    fprintf("Citations: \n");
    fprintf("Chris Veness, www.movable-type.co.uk. “Movable Type Scripts.” Calculate Distance and Bearing between Two Latitude/Longitude Points Using Haversine Formula in JavaScript, \nwww.movable-type.co.uk/scripts/latlong.html. ");
end
